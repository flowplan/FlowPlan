<?php

session_start();
$profile_name = $_SESSION['user'];
$projName = $_GET['projectName'];
$projId = $_GET['projId'];


if(isset($profile_name)){
    require_once "class.php";

    $project = new FlowPlan;
    $edit_project = $project->editProject($projName, $projId);
    
    echo json_encode($edit_project);


}
else{
    header("Location:\index.php");
}