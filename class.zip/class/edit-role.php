<?php

session_start();
$profile_name = $_SESSION['user'];
$teamId = $_GET['teamId'];
$roleName = $_GET['role'];


if(isset($profile_name)){
    require_once "class.php";

    $role = new FlowPlan;
    $edit_role = $role->editRole($teamId, $roleName);
    
    echo json_encode($edit_role);


}
else{
    header("Location:\index.php");
}