<?php
$server = "localhost";
$server_user = "root";
$server_pass = "";

$conn = new PDO("mysql:host=$server;dbname=flowPlanDB", $server_user, $server_pass);