<?php

session_start();
$profile_name = $_SESSION['user'];
$log = $_GET['id'];

if(isset($profile_name)){
    require_once "class.php";

    $report = new FlowPlan;
    $accept = $report->AcceptLog($log);
    
    echo json_encode($accept);


}
else{
    header("Location:\index.php");
}