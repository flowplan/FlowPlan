<?php
$server = "sql205.epizy.com";
$server_user = "epiz_32098148";
$server_pass = "yGHykjTvQaceVmp";

$conn = new PDO("mysql:host=$server;dbname=epiz_32098148_flowplanDb", $server_user, $server_pass);