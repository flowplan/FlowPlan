<?php

session_start();


if ($_SESSION["message"] != "you are logout"){
    
}
else
{
    echo json_encode("out");
}